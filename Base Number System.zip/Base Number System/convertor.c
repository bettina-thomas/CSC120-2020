#include <stdio.h>
#pragma warning(disable: 4996)                                                       
int convert(int n);

int main() {
    int number, result;

    printf("Enter a positive integer: ");
    scanf("%d", &number);

    result = convert(number);

   printf("conversion = %d", result);
    return 0;
}

int convert(int n) {
    if ((n / 8) != 0)
    {   //return remainder using positional notation
        return (n % 8 + 10 * convert(n / 8));
    }
    else if ((n / 8) == 0)      
        return (n % 8);
    else
        return 0;       //if input is 0
}